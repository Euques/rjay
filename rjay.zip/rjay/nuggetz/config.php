<?php 

$domainName='rjay.netlify.app';
$nuggetzUser='admin';
$nuggetzPassword='password';

?>